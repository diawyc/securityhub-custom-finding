import json
import boto3
import datetime
from datetime import date
import csv

s3 = boto3.client('s3')
securityHub = boto3.client('securityhub')
ec2_client = boto3.client("ec2")

#对过长的字段去掉
def trunc(text, limit):
    if len(text) >= limit:
        return '{}...'.format(text[:limit - 4])
    return text
#根据文件名称提供的VPC和扫描报告中的hostIP地址查询主机信息
def ec2info(ip,vpcid):
    response = ec2_client.describe_instances(
        Filters=[
            {
            'Name': 'network-interface.addresses.private-ip-address',
            'Values':[ip] },
            {
            'Name': 'vpc-id',
            'Values':[vpcid] }
            ])
    #print(response['Reservations'],len(response['Reservations']))
    if len(response['Reservations'])>0:
        info=response['Reservations'][0]['Instances'][0]
        KN=''
        tags={"Name": ""}
        role=''
        pubip=''
        #对于不一定存在的字段进行判断
        if 'KeyName' in info.keys():
            KN=info['KeyName']
        if 'Tags' in info.keys():
            if info['Tags'][0] is None:
                tags={}
            else:
                tags=info['Tags'][0]
            
        if 'IamInstanceProfile' in info.keys():
            role=info['IamInstanceProfile']["Arn"]
        if 'Association' in info['NetworkInterfaces'][0].keys():
            pubip=info['NetworkInterfaces'][0]['Association']['PublicIp']
        Id=info['InstanceId']
        ec2Type=info['InstanceType']
        ImageId=info["ImageId"]
        SubnetId=info["SubnetId"]
        LaunchedAt=info['LaunchTime'].isoformat()[:19] + "Z"
        return (Id,KN,ec2Type,ImageId,SubnetId,LaunchedAt,role,tags,pubip)
    else:
        print('skip this host which is not in use anymore with risk:',ip)
        return('skip')
def ASFF(securityHubFindings, item, resourceinfo,file_key,region, aws_account_id,position,vpcid,cveid,ref):
    #中国时间,如果是海外使用UTC d = datetime.datetime.utcnow()
    d = datetime.datetime.now()
    new_recorded_time = d.isoformat() + "Z"
    securityHubFindings.append(
            {
                'ProductArn': 'arn:aws-cn:securityhub:' + region + ':'+aws_account_id+':product/'+aws_account_id+'/default',#中国要改成aws-cn否则报AccessDenied
                'Types': [
                    'Software and Configuration Checks/Vulnerabilities/CVE'
                ],
                'FirstObservedAt': new_recorded_time,
                'LastObservedAt': new_recorded_time,
                'CreatedAt': new_recorded_time,
                "Vulnerabilities": [
                  {
                    "ReferenceUrls":ref,
                    "Id": cveid
                  }
                ],
                "FindingProviderFields": {
                    "Types": ["Software and Configuration Checks/Vulnerabilities/CVE"],
                    "Severity": {
                        "Original": item[3].upper(),
                        "Label": item[3].upper()
                    },
                },
                'ProductFields': {
                    'CVE': item[1],
                    'Plugin Output': item[12],
                    'Metasploit': item[23],
                    "ProviderName":'Tenable',
                },
                 'Remediation': {
                    "Recommendation": {
                        "Text": str(item[10])}},
                'SchemaVersion': '2018-10-08',
                'GeneratorId': 'NessusScanner ' + 'tenable-plugin-{}'.format(item[0]),
                'Title': item[7]+':'+item[8],
                'UpdatedAt': new_recorded_time,
                'AwsAccountId': aws_account_id,
                'Description': trunc(item[9],1024),
                'Id':'arn:aws-cn:nessus:'+region+':'+aws_account_id+':finding/'+file_key+position,
                'Resources': [
                    {
                        "Partition": "aws",
                        'Type': 'AwsEc2Instance',
                        "Region": region,
                        "Tags":resourceinfo[7] ,
                        "Details": {
                            "AwsEc2Instance": {
                                "KeyName": resourceinfo[1],
                                "Type": resourceinfo[2],
                                "VpcId":vpcid,
                                "ImageId": resourceinfo[3],
                                "IpV4Addresses": [
                                  item[4],
                                  resourceinfo[8]
                                ],
                                "SubnetId": resourceinfo[4],
                                "LaunchedAt": resourceinfo[5],
                                "IamInstanceProfileArn": resourceinfo[6]
                              }
                            },
                        'Id': 'arn:aws:ec2:'+region+':'+aws_account_id+':instance/'+resourceinfo[0]
                    }
                ]
            })
    
    
    
    
def lambda_handler(event, context):
    # get the bucket name so that we can get the file from s3
    bucket_name = event["detail"]["bucket"]["name"]
    file_key = event["detail"]['object']['key']
    aws_account_id = event["account"]
    region = event['region']
    vpcid=file_key[:21]
    # get the object
    obj = s3.get_object(Bucket=bucket_name, Key=file_key)
    data = obj['Body'].read().decode('utf-8').splitlines()
    file_read = list(csv.reader(data))
    testResult = file_read[1:len(file_read)]
    print('本文件中共有 '+str(len(testResult))+' 条数据')
    securityHubFindings = []
    myfindings=[]
    # iterate through each result item and generate security finding format
    for item in testResult: 
        position=str(testResult.index(item)+1)
        if item[3].upper() not in ['LOW','HIGH','CRITICAL','MEDIUM']:
            continue
        ref=trunc(item[11],512).splitlines()
        if len(item[11])==0:
            ref=["https://www.tenable.com"]
        ip=item[4]
        cveid=item[1].upper()
        if len(item[1])==0:
            cveid='CVE-2000-00000'
            
        resourceinfo=ec2info(ip,vpcid)
        if resourceinfo=='skip':
            continue
        else:
            resourceinfo=ec2info(ip,vpcid)
            ASFF(securityHubFindings,item,resourceinfo,file_key,region,aws_account_id,position,vpcid,cveid,ref)
    findingsLeft = True
    startIndex = 0
    number = len(securityHubFindings)
    print('Uploading totally '+str(number)+' findings from NessusScanner.All the informational ones are skipped')
    
    # Loop through the findings sending 100 batch at a time to Security Hub
    while findingsLeft:
        stopIndex = startIndex + 100
        if stopIndex > number:
            stopIndex = number
            findingsLeft = False
        else:
            stopIndex = 100
        myfindings = securityHubFindings[startIndex:stopIndex]
        # submit the finding to Security Hub
        result = securityHub.batch_import_findings(Findings = myfindings)
        startIndex = startIndex + 100
    
    return(result)

